# Advanced DataGridView
v1.0.6
[RU](Documentation-(RU)) +EN+
----
### Contents {anchor:сontents}
# [#Description](#Description)
# [Classes and public methods](#Classes)
# [Localization](#Loc)
# [SearchToolBar Control](#Search)
# [How to use](#How)
# [Example code](#Example)

### Description  {anchor:Description }
[back](#сontents) 

### Classes and public methods{anchor:Classes}
[back](#сontents) 
{code:c#}
public class AdvancedDataGridView : DataGridView  // Main class
{
       public Boolean AutoGenerateContextFilters {get; set;} // Automatic add filters when new columns added
       public Boolean DateWithTime {get; set;} // 
       public Boolean TimeFilter {get; set;}
       public String SortString {get; private set;}
       public String FilterString {get; private set;}
 
       public event EventHandler SortStringChanged;
       public event EventHandler FilterStringChanged;

       public void EnableFilter(DataGridViewColumn Column)
       public void EnableFilter(DataGridViewColumn Column, Boolean DateWithTime, Boolean TimeFilter)
       public void DisableFilter(DataGridViewColumn Column)
       public void LoadFilter(String Filter, String Sorting = null)
       public void ClearSort(Boolean FireEvent = false)
       public void ClearFilter(Boolean FireEvent = false)
       public DataGridViewCell FindCell(string ValueToFind, string ColumnName = null, int RowIndex = 0, int ColumnIndex = 0, Boolean isWholeWordSearch = true, Boolean isCaseSensitive = false)
}
{code:c#}



### Localization{anchor:Loc}
[back](#сontents) 

### SearchToolBar Control{anchor:Search}
[back](#сontents) 

### How to use{anchor:How}
[back](#сontents) 

### Example code{anchor:Example}
[back](#сontents) 
