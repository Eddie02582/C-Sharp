# Advanced DataGridView
v1.0.6
+RU+ [EN](Documentation)
----
### Содержание {anchor:сontents}
# [Описание](#Description)
# [Инструкция](#How)
# [Классы и методы](#Classes)
# [SearchToolBar](#Search)
# [Локализация](#Loc)
# [Пример](#Example)

### Описание{anchor:Description }
[back](#сontents) 

### Инструкция{anchor:How}
[back](#сontents) 

### Классы и методы{anchor:Classes}
**AdvancedDataGridView.cs**
Основной класс {code:c#}
public class AdvancedDataGridView : DataGridView
{code:c#}
Автоматически добавляет фильтр при добавлении нового столбца {code:c#}
       public Boolean AutoGenerateContextFilters {get; set;}
{code:c#}

При фильтрации дат значения часов, минут, секунд и миллисекунд отбрасываются {code:c#}
       public Boolean DateWithTime {get; set;} 
{code:c#}

К дереву дат в фильтре добавляются фильтр часов, минут, секунд, миллисекунд {code:c#}
       public Boolean TimeFilter {get; set;}
{code:c#}

Итоговая строка сортировки{code:c#}
       public String SortString {get; private set;}
{code:c#}

Итоговая строка фильтра {code:c#}
       public String FilterString {get; private set;}
{code:c#}

Событие возникает при изменении _SortString_ {code:c#}
       public event EventHandler SortStringChanged;
{code:c#}

Событие возникает при изменении _FilterString_ {code:c#}
       public event EventHandler FilterStringChanged;
{code:c#}

Включает фильтр для _Column_ {code:c#}
       public void EnableFilter(DataGridViewColumn Column)
{code:c#}

Включает фильтр для _Column_ с заданными настройками _DateWithTime_ и _TimeFilter_, если фильтр уже включен, то только меняет настройки _DateWithTime_ и _TimeFilter_ {code:c#}
       public void EnableFilter(DataGridViewColumn Column, Boolean DateWithTime, Boolean TimeFilter)
{code:c#}

Скрывает фильтр для _Column_ {code:c#}
       public void DisableFilter(DataGridViewColumn Column)
{code:c#}

Загружает фильтр и сортировку для таблицы {code:c#}
       public void LoadFilter(String Filter, String Sorting = null)
{code:c#}

Удаляет все сортировки. Если _FireEvent = true_, то возникает событие _SortStringChanged_ {code:c#}
       public void ClearSort(Boolean FireEvent = false)
{code:c#}

Удаляет все фильтры. Если _FireEvent = true_, то возникает событие _FilterStringChanged_  {code:c#}
       public void ClearFilter(Boolean FireEvent = false)
{code:c#}

Поиск по отфильтрованным ячейкам. 
* Возвращает первую _DataGridViewCell_ у которой _FormatedValue_ совпало с _ValueToFind_.
* _ColumnName_ - имя столбца в котором осуществляется поиск, если _null_, то поиск по всем столбцам. 
* _ColumnIndex _ - номер столбца с которого начинать поиск. Если   _ColumnIndex!=ColumnName.Index_, то поиск начинается со следующей строки. Если _ColumnIndex>0_  и _ColumnName!=null_, то поиск идет только в столбцах с _Index>ColumnIndex_.
* _isWholeWordSearch_ - искать слово целиком. 
* _isCaseSensitive_ - учитывать регистр 
{code:c#}
       public DataGridViewCell FindCell(string ValueToFind, string ColumnName = null, int RowIndex = 0, int ColumnIndex = 0, Boolean isWholeWordSearch = true, Boolean isCaseSensitive = false)
{code:c#}

**ADGVColumnHeaderCell.cs**
_DataGridViewColumnHeaderCell_, который содержит кнопку для фильтра 
{code:c#}
public class ADGVColumnHeaderCell : DataGridViewColumnHeaderCell
{code:c#}

_ADGVFilterMenu_, который привязан к _DataGridViewColumnHeaderCell_
{code:c#}
        public ADGVFilterMenu FilterMenu { get; private set; }
{code:c#}

Событие возникает когда нажимают на кнопку фильтра
{code:c#}
        public event ADGVFilterEventHandler FilterPopup;
{code:c#}

Событие возникает когда у привязанного _FilterMenu _ меняется _SortString_
{code:c#}
        public event ADGVFilterEventHandler SortChanged;
{code:c#}

Событие возникает когда у привязанного  _FilterMenu_ меняется _FilterString_
{code:c#}
        public event ADGVFilterEventHandler FilterChanged;
{code:c#}

Минимальные размеры ячейки, которые должны быть чтобы хватило места для размещения кнопки фильтра
{code:c#}
        public Size MinimumSize {get; }
{code:c#}

Активный стиль сортировки _FilterMenu_
{code:c#}
        public ADGVFilterMenuSortType ActiveSortType {get; }
{code:c#}

Активный тип фильтра _FilterMenu_
{code:c#}
        public ADGVFilterMenuFilterType ActiveFilterType {get; }
{code:c#}

Итоговая строка сортировки _FilterMenu_
{code:c#}
        public String SortString {get; }
{code:c#}

Итоговая строка фильтра _FilterMenu_
{code:c#}
        public String FilterString {get; }
{code:c#}

Включен или нет _FilterMenu_. Когда фильтр отключен кнопка фильтра не отображается.
{code:c#}
        public Boolean FilterEnabled {get; set;}
{code:c#}

Возвращает или устанавливает _FilterMenu.DateWithTime_
{code:c#}
        public Boolean DateWithTime {get; set;}
{code:c#}

Возвращает или устанавливает _FilterMenu.TimeFilter_
{code:c#}
        public Boolean TimeFilter {get; set;}
{code:c#}

Вызывает SetLoadedFilterMode(Boolean Enabled)
{code:c#}
        public void SetLoadedFilterMode(Boolean Enabled)
{code:c#}

Конструктор. _oldCell_ -  оригинальная ячейка _DataGridViewColumnHeaderCell_ для замены
{code:c#}
        public ADGVColumnHeaderCell(DataGridViewColumnHeaderCell oldCell, Boolean FilterEnabled = false)
{code:c#}

[back](#сontents)

### SearchToolBar {anchor:Search}
[back](#сontents) 

### Локализация{anchor:Loc}
[back](#сontents) 

### Пример {anchor:Example}
[back](#сontents) 